import React from 'react';

const TermsCondition = () => {
    return (
        <div className='my-40 flex justify-center items-center'>
          <p className='font-bold text-2xl'>  please read the carefully terms and condition </p>
        </div>
    );
};

export default TermsCondition;