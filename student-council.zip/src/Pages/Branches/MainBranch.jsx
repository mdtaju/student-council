import { Container } from '@mui/material';
import React from 'react';

const MainBranch = () => {
    return (
        <Container className='py-40'>
            <h1 className='text-3xl'>welcome to Main branches page </h1>
        </Container>
    );
};

export default MainBranch;