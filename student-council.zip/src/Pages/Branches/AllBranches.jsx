import { Container } from '@mui/material';
import React from 'react';

const AllBranches = () => {
    return (
        <Container className='py-40'>
            <h1 className='text-3xl'>welcome to All branches page </h1>
        </Container>
    );
};

export default AllBranches;