import React from "react";

const SocialLinks = () => {
  return (
    <div className="fixed left-0 top-1/2">
      {/* <LinkChild icon={FacebookIcon} /> */}
    </div>
  );
};

export default SocialLinks;
