import React from "react";

const LinkChild = ({ icon }) => {
  return <div className="p-2 bg-blue-400 text-white">{icon}</div>;
};

export default LinkChild;
