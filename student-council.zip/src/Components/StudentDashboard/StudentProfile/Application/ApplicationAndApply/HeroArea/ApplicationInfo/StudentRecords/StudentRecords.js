import React from "react";

const StudentRecords = () => {
  return (
    <div>
      <h1>this is student records</h1>
    </div>
  );
};

export default StudentRecords;
