import React from "react";

const Notes = () => {
  return (
    <div>
      <h1>this is notes</h1>
    </div>
  );
};

export default Notes;
