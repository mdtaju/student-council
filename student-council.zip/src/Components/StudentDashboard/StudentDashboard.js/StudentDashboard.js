// import { PDFViewer } from "@react-pdf/renderer";
import React from "react";
// import PDFMaker from "../StudentProfile/PDFMaker/PDFMaker";
const StudentDashboard = () => {
  return (
    <div className="w-full min-h-screen grid place-items-center">
      <h1 className="text-3xl font-semibold text-secondary">
        Welcome to Dashboard
      </h1>
      {/* <PDFViewer width={"100%"} height={"100%"}>
        <PDFMaker studentData={""} />
      </PDFViewer> */}
    </div>
  );
};

export default StudentDashboard;
