exports.studentNormalPathname = [
  { path: "profile", name: "Profile" },
  // { path: "chat", name: "Message" },
  { path: "createAppointment", name: "Create Appointment" },
  { path: "myAppointments", name: "My Appointments" },
];

exports.otherStudentPathName = [
  { path: "offers", name: "Offers and Promotion" },
  { path: "notification", name: "Notification" },
  { path: "communityLink", name: "Your Community Link" },
  { path: "resource", name: "Learning Resources" },
];
